#!/bin/bash
# Coupled-edit ablation launcher: one low-priority process per model; resumable (finished trials are skipped).
cd /Users/hsuyuchia/Documents/RACE-RL
OUT=experiments/runs/coupled_edit_ablation_20261105
pids=()
for m in vgg16 mobilenet_v2 resnet18; do
  nohup nice -n 10 .venv/bin/python -u tools/coupled_edit_ablation.py run --model $m --out $OUT > $OUT/$m.console.log 2>&1 &
  pids+=($!)
done
echo "${pids[@]}" > $OUT/pids.txt
status=0
for p in "${pids[@]}"; do wait $p || status=1; done
echo "finished status=$status $(date)" > $OUT/finished.txt
exit $status
